﻿-- Exported from QuickDBD: https://www.quickdatabasediagrams.com/
-- Link to schema: https://app.quickdatabasediagrams.com/#/d/M2NBGY
-- NOTE! If you have used non-SQL datatypes in your design, you will have to change these here.


SET XACT_ABORT ON

BEGIN TRANSACTION QUICKDBD

CREATE TABLE [Child] (
    [ChildID] int  NOT NULL ,
    [Name] txt  NOT NULL ,
    [Age] int  NOT NULL ,
    [DOB] txt  NOT NULL ,
    [Allergies] txt  NOT NULL ,
    [Parent] int  NOT NULL ,
    [DropOff] txt  NOT NULL ,
    [PickUp] txt  NOT NULL ,
    [Instructors] txt  NOT NULL ,
    [Instructions] txt  NOT NULL ,
    CONSTRAINT [PK_Child] PRIMARY KEY CLUSTERED (
        [ChildID] ASC
    )
)

CREATE TABLE [Parent] (
    [ParentID] int  NOT NULL ,
    [Name] txt  NOT NULL ,
    [Address] txt  NOT NULL ,
    [Child] txt  NOT NULL ,
    [CoParent] txt  NOT NULL ,
    [CarInfo] txt  NOT NULL ,
    [Plate] txt  NOT NULL ,
    [License] txt  NOT NULL ,
    CONSTRAINT [PK_Parent] PRIMARY KEY CLUSTERED (
        [ParentID] ASC
    )
)

CREATE TABLE [Staff] (
    [StaffID] int  NOT NULL ,
    [Address] txt  NOT NULL ,
    [Children] txt  NOT NULL ,
    [Pay] txt  NOT NULL ,
    CONSTRAINT [PK_Staff] PRIMARY KEY CLUSTERED (
        [StaffID] ASC
    )
)

CREATE TABLE [Supplies] (
    [Books] txt  NOT NULL ,
    [Tech] txt  NOT NULL ,
    [Writing] txt  NOT NULL ,
    [Child] int  NOT NULL 
)

ALTER TABLE [Child] WITH CHECK ADD CONSTRAINT [FK_Child_Parent] FOREIGN KEY([Parent])
REFERENCES [Parent] ([ParentID])

ALTER TABLE [Child] CHECK CONSTRAINT [FK_Child_Parent]

ALTER TABLE [Child] WITH CHECK ADD CONSTRAINT [FK_Child_Instructors] FOREIGN KEY([Instructors])
REFERENCES [Staff] ([StaffID])

ALTER TABLE [Child] CHECK CONSTRAINT [FK_Child_Instructors]

ALTER TABLE [Parent] WITH CHECK ADD CONSTRAINT [FK_Parent_Child] FOREIGN KEY([Child])
REFERENCES [Child] ([ChildID])

ALTER TABLE [Parent] CHECK CONSTRAINT [FK_Parent_Child]

ALTER TABLE [Staff] WITH CHECK ADD CONSTRAINT [FK_Staff_Children] FOREIGN KEY([Children])
REFERENCES [Child] ([ChildID])

ALTER TABLE [Staff] CHECK CONSTRAINT [FK_Staff_Children]

ALTER TABLE [Supplies] WITH CHECK ADD CONSTRAINT [FK_Supplies_Child] FOREIGN KEY([Child])
REFERENCES [Child] ([ChildID])

ALTER TABLE [Supplies] CHECK CONSTRAINT [FK_Supplies_Child]

CREATE INDEX [idx_Child_Name]
ON [Child] ([Name])

COMMIT TRANSACTION QUICKDBD